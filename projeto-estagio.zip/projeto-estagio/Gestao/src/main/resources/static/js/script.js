// Array que simula o banco de dados dos clientes
let clientes = [];
let clienteEditando = null; // Variável para armazenar cliente sendo editado

// Função para validar CPF
function isValidCPF(cpf) {
    cpf = cpf.replace(/[^\d]+/g, ''); // Remove caracteres não numéricos
    if (cpf.length !== 11 || /^(\d)\1{10}$/.test(cpf)) return false;

    let sum = 0;
    let remainder;

    for (let i = 1; i <= 9; i++) sum += parseInt(cpf.charAt(i - 1)) * (11 - i);
    remainder = (sum * 10) % 11;
    if (remainder === 10 || remainder === 11) remainder = 0;
    if (remainder !== parseInt(cpf.charAt(9))) return false;

    sum = 0;
    for (let i = 1; i <= 10; i++) sum += parseInt(cpf.charAt(i - 1)) * (12 - i);
    remainder = (sum * 10) % 11;
    if (remainder === 10 || remainder === 11) remainder = 0;
    if (remainder !== parseInt(cpf.charAt(10))) return false;

    return true;
}

// Função para verificar se o CPF já está cadastrado
function isUniqueCPF(cpf) {
    if (clienteEditando && clienteEditando.cpf === cpf) return true; // Permite edição do próprio CPF
    return !clientes.some(client => client.cpf === cpf);
}

// Função para validar o formulário
function validateForm(event) {
    event.preventDefault();

    const nome = document.getElementById('nome').value.trim();
    const cpf = document.getElementById('cpf').value.trim();
    const dataNascimento = document.getElementById('dataNascimento').value;
    const endereco = document.getElementById('endereco').value.trim();
    const errorMessages = document.getElementById('errorMessages');
    errorMessages.innerHTML = '';

    let isValid = true;

    if (!nome || !cpf || !dataNascimento || !endereco) {
        errorMessages.innerHTML += '<p>Todos os campos são obrigatórios!</p>';
        isValid = false;
    }

    if (cpf && !isValidCPF(cpf)) {
        errorMessages.innerHTML += '<p>CPF inválido!</p>';
        isValid = false;
    }

    if (cpf && !isUniqueCPF(cpf)) {
        errorMessages.innerHTML += '<p>CPF já cadastrado!</p>';
        isValid = false;
    }

    if (isValid) {
        saveClientData(nome, cpf, dataNascimento, endereco);
    }
}

// Função para salvar ou atualizar cliente
function saveClientData(nome, cpf, dataNascimento, endereco) {
    if (clienteEditando) {
        // Atualiza os dados do cliente existente
        clienteEditando.nome = nome;
        clienteEditando.cpf = cpf;
        clienteEditando.dataNascimento = dataNascimento;
        clienteEditando.endereco = endereco;
        clienteEditando = null; // Reseta a variável após edição
    } else {
        // Adiciona novo cliente
        clientes.push({ nome, cpf, dataNascimento, endereco });
    }

    document.getElementById('errorMessages').innerHTML = '<p>Cliente salvo com sucesso!</p>';
    document.getElementById('clientForm').reset();
    updateClientTable(); // Atualiza a tabela após salvar
}

// Função para atualizar a tabela de clientes
function updateClientTable() {
    const tableBody = document.getElementById('clientTableBody');
    tableBody.innerHTML = ''; // Limpa a tabela antes de atualizar

    if (clientes.length === 0) {
        tableBody.innerHTML = '<tr><td colspan="5" style="text-align: center;">Nenhum cliente cadastrado</td></tr>';
        return;
    }

    clientes.forEach(client => {
        const row = document.createElement('tr'); // Cria uma nova linha para o cliente
        row.innerHTML = `
            <td>${client.nome}</td>
            <td>${client.cpf}</td>
            <td>${client.dataNascimento}</td>
            <td>${client.endereco}</td>
            <td>
                <button onclick="editClient('${client.cpf}')">Editar</button>
                <button onclick="deleteClient('${client.cpf}')">Excluir</button>
            </td>
        `;
        tableBody.appendChild(row); // Adiciona a linha à tabela
    });
}

// Função para editar cliente
function editClient(cpf) {
    clienteEditando = clientes.find(c => c.cpf === cpf);
    if (clienteEditando) {
        document.getElementById('nome').value = clienteEditando.nome;
        document.getElementById('cpf').value = clienteEditando.cpf;
        document.getElementById('dataNascimento').value = clienteEditando.dataNascimento;
        document.getElementById('endereco').value = clienteEditando.endereco;
        document.getElementById('cpf').disabled = true; // Evita edição do CPF
    }
}

// Função para excluir cliente
function deleteClient(cpf) {
    clientes = clientes.filter(client => client.cpf !== cpf); // Remove o cliente da lista
    updateClientTable(); // Atualiza a tabela após a exclusão
}

// Evento para submissão do formulário
document.getElementById('clientForm').addEventListener('submit', validateForm);

// Carregar clientes ao iniciar a página
document.addEventListener('DOMContentLoaded', updateClientTable);

// Função para salvar o cliente
function saveClientData(nome, cpf, dataNascimento, endereco) {
    fetch('http://localhost:3000/salvarCliente', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        nome,
        cpf,
        dataNascimento,
        endereco,
      }),
    })
      .then(response => response.text())
      .then(data => {
        alert(data);
        updateClientTable(); // Atualiza a tabela de clientes após o cadastro
      })
      .catch(error => console.error('Erro ao salvar cliente:', error));
  }
  
  // Função para atualizar a tabela de clientes
  function updateClientTable() {
    fetch('http://localhost:3000/clientes')
      .then(response => response.json())
      .then(data => {
        const tableBody = document.getElementById('clientTableBody');
        tableBody.innerHTML = '';
  
        data.forEach(client => {
          const row = tableBody.insertRow();
          row.innerHTML = `
            <td>${client.nome}</td>
            <td>${client.cpf}</td>
            <td>${client.data_nascimento}</td>
            <td>${client.endereco}</td>
          `;
        });
      })
      .catch(error => console.error('Erro ao buscar clientes:', error));
  }
  
  // Atualiza a tabela de clientes ao carregar a página
  window.onload = updateClientTable;
  