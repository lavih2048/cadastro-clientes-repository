let clientes = JSON.parse(localStorage.getItem('clientes')) || [];
let clienteEditando = null;

function isValidCPF(cpf) {
    cpf = cpf.replace(/[^\d]+/g, '');
    if (cpf.length !== 11 || /^(\d)\1{10}$/.test(cpf)) return false;

    let sum = 0;
    for (let i = 1; i <= 9; i++) sum += parseInt(cpf.charAt(i - 1)) * (11 - i);
    let remainder = (sum * 10) % 11;
    if (remainder === 10 || remainder === 11) remainder = 0;
    if (remainder !== parseInt(cpf.charAt(9))) return false;

    sum = 0;
    for (let i = 1; i <= 10; i++) sum += parseInt(cpf.charAt(i - 1)) * (12 - i);
    remainder = (sum * 10) % 11;
    if (remainder === 10 || remainder === 11) remainder = 0;
    if (remainder !== parseInt(cpf.charAt(10))) return false;

    return true;
}

function isUniqueCPF(cpf) {
    if (clienteEditando && clienteEditando.cpf === cpf) return true;
    return !clientes.some(client => client.cpf === cpf);
}

function validateForm(event) {
    event.preventDefault();

    const nome = document.getElementById('nome').value.trim();
    const cpf = document.getElementById('cpf').value.trim();
    const dataNascimento = document.getElementById('dataNascimento').value;
    const endereco = document.getElementById('endereco').value.trim();
    const errorMessages = document.getElementById('errorMessages');
    errorMessages.innerHTML = '';

    let isValid = true;

    if (!nome || !cpf || !dataNascimento || !endereco) {
        errorMessages.innerHTML += '<p>Todos os campos são obrigatórios!</p>';
        isValid = false;
    }

    if (cpf && !isValidCPF(cpf)) {
        errorMessages.innerHTML += '<p>CPF inválido!</p>';
        isValid = false;
    }

    if (cpf && !isUniqueCPF(cpf)) {
        errorMessages.innerHTML += '<p>CPF já cadastrado!</p>';
        isValid = false;
    }

    if (isValid) {
        saveClientData(nome, cpf, dataNascimento, endereco);
    }
}

function saveClientData(nome, cpf, dataNascimento, endereco) {
    if (clienteEditando) {
        clienteEditando.nome = nome;
        clienteEditando.cpf = cpf;
        clienteEditando.dataNascimento = dataNascimento;
        clienteEditando.endereco = endereco;
        clienteEditando = null;
        document.getElementById('cpf').disabled = false;
    } else {
        clientes.push({ nome, cpf, dataNascimento, endereco });
    }

    localStorage.setItem('clientes', JSON.stringify(clientes));
    document.getElementById('errorMessages').innerHTML = '<p style="color:green;">Cliente salvo com sucesso!</p>';
    document.getElementById('clientForm').reset();
    updateClientTable();
}

function updateClientTable() {
    const tableBody = document.getElementById('clientTableBody');
    tableBody.innerHTML = '';

    if (clientes.length === 0) {
        tableBody.innerHTML = '<tr><td colspan="5" style="text-align: center;">Nenhum cliente cadastrado</td></tr>';
        return;
    }

    clientes.forEach(client => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${client.nome}</td>
            <td>${client.cpf}</td>
            <td>${client.dataNascimento}</td>
            <td>${client.endereco}</td>
            <td>
                <button onclick="editClient('${client.cpf}')">Editar</button>
                <button onclick="deleteClient('${client.cpf}')">Excluir</button>
            </td>
        `;
        tableBody.appendChild(row);
    });
}

function editClient(cpf) {
    clienteEditando = clientes.find(c => c.cpf === cpf);
    if (clienteEditando) {
        document.getElementById('nome').value = clienteEditando.nome;
        document.getElementById('cpf').value = clienteEditando.cpf;
        document.getElementById('dataNascimento').value = clienteEditando.dataNascimento;
        document.getElementById('endereco').value = clienteEditando.endereco;
        document.getElementById('cpf').disabled = true;
    }
}

function deleteClient(cpf) {
    clientes = clientes.filter(client => client.cpf !== cpf);
    localStorage.setItem('clientes', JSON.stringify(clientes));
    updateClientTable();
}

document.getElementById('clientForm').addEventListener('submit', validateForm);
document.addEventListener('DOMContentLoaded', updateClientTable);
