import express from 'express';
import { createConnection } from 'mysql2';
import { json } from 'body-parser';

// Inicialização do express
const app = express();
const port = 3000;

// Configuração do middleware
app.use(json()); // Para interpretar JSON no corpo da requisição

// Configuração do middleware para permitir CORS (evitando credenciais sensíveis à exposição)
require('dotenv').config();

// Configuração do MySQL
const db = createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
});

// Conexão com o MySQL
db.connect((err) => {
  if (err) {
    console.error('Erro de conexão com o banco de dados:', err);
  } else {
    console.log('Conectado ao banco de dados MySQL');
  }
});

// Rota para obter todos os clientes
app.get('/api/clientes', (req, res) => {
  db.query('SELECT * FROM clientes', (err, results) => {
    if (err) {
      return res.status(500).send('Erro ao consultar os clientes.');
    }
    res.json(results); // Retorna todos os clientes
  });
});

// Rota para adicionar um cliente
app.post('/api/clientes', (req, res) => {
  const { nome, cpf, dataNascimento, endereco } = req.body;
  const sql = 'INSERT INTO clientes (nome, cpf, dataNascimento, endereco) VALUES (?, ?, ?, ?)';
  db.query(sql, [nome, cpf, dataNascimento, endereco], (err, result) => {
    if (err) {
      return res.status(500).send('Erro ao salvar o cliente.');
    }
    res.status(201).send('Cliente salvo com sucesso.');
  });
});

// Rota para deletar um cliente
app.delete('/api/clientes/:cpf', (req, res) => {
  const { cpf } = req.params;
  const sql = 'DELETE FROM clientes WHERE cpf = ?';
  db.query(sql, [cpf], (err, result) => {
    if (err) {
      return res.status(500).send('Erro ao excluir o cliente.');
    }
    res.send('Cliente excluído com sucesso.');
  });
});

// Iniciar o servidor
app.listen(port, () => {
  console.log(`Servidor rodando na porta ${port}`);
});
